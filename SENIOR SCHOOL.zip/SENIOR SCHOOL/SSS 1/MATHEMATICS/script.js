// ==========================
// --- Questions Arrays ---
// ==========================

// --- SSS1 (70 questions) ---
const SSS1_questions = [
  { q: "What is the sum of twelve and eight?", a: "20" },
  { q: "What is the difference between twenty and nine?", a: "11" },
  { q: "Calculate the product of five and six.", a: "30" },
  { q: "Divide thirty by six and give the result.", a: "5" },
  { q: "What is one half of thirty-six?", a: "18" },
  { q: "Write three quarters of twenty as a number.", a: "15" },
  { q: "Convert two hundred and fifty centimetres to metres.", a: "2.5" },
  { q: "Add two point five and one point seven five.", a: "4.25" },
  { q: "Round forty-seven to the nearest ten.", a: "50" },
  { q: "Find the least common multiple of four and six.", a: "12" },
  { q: "Find the highest common factor of twelve and eighteen.", a: "6" },
  { q: "Calculate the perimeter of a square with side five centimetres.", a: "20" },
  { q: "Calculate the area of a rectangle of length five centimetres and width four centimetres.", a: "20" },
  { q: "What is ten percent of two hundred?", a: "20" },
  { q: "Express zero point two five as a fraction in simplest form.", a: "1/4" },
  { q: "Convert three kilometres to metres.", a: "3000" },
  { q: "Simplify: nine times two minus five.", a: "13" },
  { q: "If x equals three, evaluate two x plus one.", a: "7" },
  { q: "Find the result of seven plus eight plus five.", a: "20" },
  { q: "Find half of ninety.", a: "45" },
  { q: "Write the next number in the sequence 2, 4, 6, 8, ...", a: "10" },
  { q: "What is four squared?", a: "16" },
  { q: "Express fifty percent as a decimal.", a: "0.5" },
  { q: "Calculate three times four plus two.", a: "14" },
  { q: "If a equals five, what is a plus a?", a: "10" },
  { q: "Convert one point five hours to minutes.", a: "90" },
  { q: "Write seventy-five percent as a decimal.", a: "0.75" },
  { q: "Calculate one hundred minus thirty-seven.", a: "63" },
  { q: "Find the perimeter of a triangle with sides three, four and five centimetres.", a: "12" },
  { q: "What is two fifths of fifty?", a: "20" },
  { q: "Add the fractions one quarter and one quarter.", a: "1/2" },
  { q: "Calculate five minus two point five.", a: "2.5" },
  { q: "Multiply zero point five by twelve.", a: "6" },
  { q: "Divide thirty-six by nine.", a: "4" },
  { q: "What is eight times seven?", a: "56" },
  { q: "If one book costs ₦50, what is the cost of four books?", a: "200" },
  { q: "Calculate eleven plus thirteen.", a: "24" },
  { q: "Find half of sixty-four.", a: "32" },
  { q: "Calculate nine times five minus ten.", a: "35" },
  { q: "Convert five thousand metres to kilometres.", a: "5" },
  { q: "Round one hundred and twenty-three to the nearest hundred.", a: "100" },
  { q: "Evaluate three times the sum of two and four.", a: "18" },
  { q: "If y equals two, what is three times y?", a: "6" },
  { q: "Write two point two five as a mixed number.", a: "2 1/4" },
  { q: "Find twenty-five percent of eighty.", a: "20" },
  { q: "Calculate fourteen minus nine.", a: "5" },
  { q: "Find the least common multiple of three and five.", a: "15" },
  { q: "Find the highest common factor of eight and twelve.", a: "4" },
  { q: "Calculate the area of a square with side seven centimetres.", a: "49" },
  { q: "Find the perimeter of a rectangle with sides six and three centimetres.", a: "18" },
  { q: "If a equals two and b equals three, find a plus b.", a: "5" },
  { q: "What is fifteen divided by five?", a: "3" },
  { q: "Add three tenths and four tenths.", a: "7/10" },
  { q: "What is ten times ten?", a: "100" },
  { q: "Convert two thousand five hundred metres to kilometres.", a: "2.5" },
  { q: "Simplify seven plus six minus four.", a: "9" },
  { q: "Calculate four times four times two.", a: "32" },
  { q: "If x equals four, evaluate two x plus three.", a: "11" },
  { q: "Divide eighteen by two.", a: "9" },
  { q: "Find the perimeter of a square with side nine centimetres.", a: "36" },
  { q: "What is the mode of the set 2, 2, 3, 4, 4, 4, 5?", a: "4" },
  { q: "Find the mean of the numbers two, four and six.", a: "4" },
  { q: "What is two multiplied by zero?", a: "0" },
  { q: "Simplify three plus five times two (use order of operations).", a: "13" },
  { q: "Express zero point one two five as a fraction.", a: "1/8" },
  { q: "Find one third of twenty-one.", a: "7" },
  { q: "What is seven times six?", a: "42" },
  { q: "Convert two hundred millilitres to litres.", a: "0.2" },
  { q: "Find thirty percent of sixty.", a: "18" },
  { q: "Find the least common multiple of five and ten.", a: "10" }
];


let currentLevel = [];
let currentQuestionIndex = 0;
let score = 0;
let timer;
let timeLeft = 60;

const questionEl = document.getElementById("question");
const answerEl = document.getElementById("answer");
const scoreEl = document.getElementById("score");
const timerEl = document.getElementById("timer");

function startGame(level) {
  document.getElementById("level-selection").style.display = "none";
  document.getElementById("game").style.display = "block";
  currentQuestionIndex = 0;
  score = 0;

  if(level === "SSS1") currentLevel = SSS1_questions;
  
  showQuestion();
}

function showQuestion() {
  if(currentQuestionIndex >= currentLevel.length){
    questionEl.textContent = "Game Over!";
    scoreEl.textContent = "Your score: " + score + "/" + currentLevel.length;
    clearInterval(timer);
    return;
  }

  questionEl.textContent = currentLevel[currentQuestionIndex].q;
  answerEl.value = "";
  timeLeft = 60;
  timerEl.textContent = "Time: 60s";

  clearInterval(timer);
  timer = setInterval(() => {
    timeLeft--;
    timerEl.textContent = "Time: " + timeLeft + "s";
    if(timeLeft <= 0){
      currentQuestionIndex++;
      showQuestion();
    }
  }, 1000);
}

document.getElementById("submit").addEventListener("click", function(){
  let userAnswer = answerEl.value.trim();
  let correctAnswer = currentLevel[currentQuestionIndex].a;
  if(userAnswer === correctAnswer.toString()) score++;
  currentQuestionIndex++;
  showQuestion();
});

// ==========================
// --- Calculator ---
// ==========================
function calcPress(value){
  document.getElementById("calcDisplay").value += value;
}

function calcClear(){
  document.getElementById("calcDisplay").value = "";
}

function calcCalculate(){
  try {
    let result = eval(document.getElementById("calcDisplay").value);
    document.getElementById("calcDisplay").value = result;
  } catch(e){
    document.getElementById("calcDisplay").value = "Error";
  }
}
