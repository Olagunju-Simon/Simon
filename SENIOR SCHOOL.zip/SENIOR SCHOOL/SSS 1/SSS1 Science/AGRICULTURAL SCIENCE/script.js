// ================== QUIZ QUESTION SETS ==================
const set1 = [
  {question:"What is the symbol for Hydrogen?",answers:[{text:"H",correct:true},{text:"He",correct:false},{text:"Hy",correct:false},{text:"Ho",correct:false}]},
  {question:"Which element has the symbol 'He'?",answers:[{text:"Helium",correct:true},{text:"Hydrogen",correct:false},{text:"Hafnium",correct:false},{text:"Holmium",correct:false}]},
  {question:"What is the atomic number of Lithium?",answers:[{text:"2",correct:false},{text:"3",correct:true},{text:"4",correct:false},{text:"5",correct:false}]},
  {question:"Which element has the symbol 'Be'?",answers:[{text:"Boron",correct:false},{text:"Beryllium",correct:true},{text:"Bismuth",correct:false},{text:"Bohrium",correct:false}]},
  {question:"What is Chemistry?",answers:[{text:"It is the branch of science  which deals with the study of the nature, structure, composition and uses of all forms of matter",correct:true},{text:"It is only the study of all forms of matter",correct:false},{text:"It is the study of all chemicals",correct:false},{text:"I don't know",correct:false}]},
  {question:"Carbon has which symbol?",answers:[{text:"C",correct:true},{text:"Ca",correct:false},{text:"Co",correct:false},{text:"Cu",correct:false}]},
  {question:"Nitrogen has which symbol?",answers:[{text:"N",correct:true},{text:"Ni",correct:false},{text:"Ne",correct:false},{text:"No",correct:false}]},
  {question:"Which element has the symbol 'O'?",answers:[{text:"Oxygen",correct:true},{text:"Osmium",correct:false},{text:"Oganesson",correct:false},{text:"Opium",correct:false}]},
  {question:"Which branch of Chemistry deals wih the study of elements, their properties and uses?",answers:[{text:"Observation",correct:false},{text:"Inorganic",correct:true},{text:"Agriculture",correct:false},{text:"Organic",correct:false}]},
  {question:"Which element has the symbol 'Ne'?",answers:[{text:"Neon",correct:true},{text:"Neptunium",correct:false},{text:"Nickel",correct:false},{text:"Nitrogen",correct:false}]}
];

const set2 = [
  {question:"What is Matter ?",answers:[{text:"Anything that has weight and occupies space",correct:true},{text:"Anything that is Solid, liquid nad gas",correct:false},{text:"Anything that has Potassium",correct:false},{text:"Anything that has Calcium",correct:false}]},
  {question:"What is the symbol for Magnesium?",answers:[{text:"Mn",correct:false},{text:"Mg",correct:true},{text:"Ma",correct:false},{text:"Mo",correct:false}]},
  {question:"Aluminium has which symbol?",answers:[{text:"Al",correct:true},{text:"Am",correct:false},{text:"Au",correct:false},{text:"Ag",correct:false}]},
  {question:"Which element has the symbol 'Si'?",answers:[{text:"Silicon",correct:true},{text:"Sulfur",correct:false},{text:"Silver",correct:false},{text:"Selenium",correct:false}]},
  {question:"Which Branch of Chemistry deals with the study of Carbon and it's compound",answers:[{text:"Agriculture",correct:false},{text:"Teaching",correct:false},{text:"Organic",correct:true},{text:"Inorganic",correct:false}]},
  {question:"Which element has the symbol 'S'?",answers:[{text:"Sulfur",correct:true},{text:"Selenium",correct:false},{text:"Strontium",correct:false},{text:"Samarium",correct:false}]},
  {question:"Chlorine has which symbol?",answers:[{text:"Cl",correct:true},{text:"Ch",correct:false},{text:"C",correct:false},{text:"Cr",correct:false}]},
  {question:"Which element has the symbol 'Ar'?",answers:[{text:"Argon",correct:true},{text:"Arsenic",correct:false},{text:"Actinium",correct:false},{text:"Americium",correct:false}]},
  {question:"Potassium has which symbol?",answers:[{text:"P",correct:false},{text:"K",correct:true},{text:"Po",correct:false},{text:"Pt",correct:false}]},
  {question:"What is the symbol for Calcium?",answers:[{text:"C",correct:false},{text:"Ca",correct:true},{text:"Cl",correct:false},{text:"Ce",correct:false}]}
];

const set3 = [
  {question:"Scandium has what symbol?",answers:[{text:"Sc",correct:true},{text:"Se",correct:false},{text:"Sr",correct:false},{text:"Sm",correct:false}]},
  {question:"Which element has the symbol 'Ti'?",answers:[{text:"Titanium",correct:true},{text:"Tellurium",correct:false},{text:"Thallium",correct:false},{text:"Tin",correct:false}]},
  {question:"Vanadium has which symbol?",answers:[{text:"V",correct:true},{text:"Va",correct:false},{text:"Vi",correct:false},{text:"Ve",correct:false}]},
  {question:"Which element has the symbol 'Cr'?",answers:[{text:"Chromium",correct:true},{text:"Cobalt",correct:false},{text:"Cerium",correct:false},{text:"Carbon",correct:false}]},
  {question:"How many state of matter do we have?",answers:[{text:"One",correct:false},{text:"Two",correct:false},{text:"Three",correct:true},{text:"Four",correct:false}]},
  {question:"Which element has the symbol 'Fe'?",answers:[{text:"Iron",correct:true},{text:"Fluorine",correct:false},{text:"Francium",correct:false},{text:"Fermium",correct:false}]},
  {question:"Cobalt has which symbol?",answers:[{text:"Co",correct:true},{text:"Cb",correct:false},{text:"Cu",correct:false},{text:"Cr",correct:false}]},
  {question:"Which element has the symbol 'Ni'?",answers:[{text:"Nickel",correct:true},{text:"Nitrogen",correct:false},{text:"Niobium",correct:false},{text:"Neon",correct:false}]},
  {question:"How many types of change do we have",answers:[{text:"2",correct:true},{text:"1",correct:false},{text:"3",correct:false},{text:"4",correct:false}]},
  {question:"Which element has the symbol 'Zn'?",answers:[{text:"Zinc",correct:true},{text:"Zirconium",correct:false},{text:"Zyklon",correct:false},{text:"Zein",correct:false}]}
];

const set4 = [
  {question:"We have ________ and ___________ types of change",answers:[{text:"Liguid and solid",correct:false},{text:"Gaseous and Solid",correct:false},{text:"Seen and unseen",correct:false},{text:"Physical and chemical",correct:truee}]},
  {question:"Which element has the symbol 'Ge'?",answers:[{text:"Germanium",correct:true},{text:"Gallium",correct:false},{text:"Gold",correct:false},{text:"Gadolinium",correct:false}]},
  {question:"All but one are examples of physical change",answers:[{text:"Rusting of Iron",correct:false},{text:"Burning of materials",correct:false},{text:"Melting of solid",correct:true},{text:"Decay of substances",correct:false}]},
  {question:"What is the symbol for Selenium?",answers:[{text:"Se",correct:true},{text:"S",correct:false},{text:"Sr",correct:false},{text:"Si",correct:false}]},
  {question:"Which element has the symbol 'Br'?",answers:[{text:"Bromine",correct:true},{text:"Boron",correct:false},{text:"Beryllium",correct:false},{text:"Bismuth",correct:false}]},
  {question:"How many types of chemical Industries ",answers:[{text:"Kr",correct:true},{text:"K",correct:false},{text:"Ky",correct:false},{text:"Ko",correct:false}]},
  {question:"Rubidium has which symbol?",answers:[{text:"Rb",correct:true},{text:"Ru",correct:false},{text:"Re",correct:false},{text:"Rn",correct:false}]},
  {question:"Which element has the symbol 'Sr'?",answers:[{text:"Strontium",correct:true},{text:"Selenium",correct:false},{text:"Samarium",correct:false},{text:"Sulfur",correct:false}]},
  {question:"Yttrium has which symbol?",answers:[{text:"Y",correct:true},{text:"Yb",correct:false},{text:"Yt",correct:false},{text:"Yn",correct:false}]},
  {question:"What is the symbol for Zirconium?",answers:[{text:"Zr",correct:true},{text:"Zn",correct:false},{text:"Ze",correct:false},{text:"Zo",correct:false}]}
];

const set5 = [
  {question:"Which element has the symbol 'Nb'?",answers:[{text:"Niobium",correct:true},{text:"Nickel",correct:false},{text:"Neon",correct:false},{text:"Nobelium",correct:false}]},
  {question:"What is the symbol for Molybdenum?",answers:[{text:"Mo",correct:true},{text:"Mb",correct:false},{text:"Mn",correct:false},{text:"Mg",correct:false}]},
  {question:"Technetium has which symbol?",answers:[{text:"Tc",correct:true},{text:"Te",correct:false},{text:"Th",correct:false},{text:"Tm",correct:false}]},
  {question:"Which element has the symbol 'Ru'?",answers:[{text:"Ruthenium",correct:true},{text:"Rubidium",correct:false},{text:"Radium",correct:false},{text:"Rhenium",correct:false}]},
  {question:"Rhodium has what symbol?",answers:[{text:"Rh",correct:true},{text:"Rn",correct:false},{text:"Ru",correct:false},{text:"Ra",correct:false}]},
  {question:"Which element has the symbol 'Pd'?",answers:[{text:"Palladium",correct:true},{text:"Polonium",correct:false},{text:"Platinum",correct:false},{text:"Protactinium",correct:false}]},
  {question:"Silver has which symbol?",answers:[{text:"Ag",correct:true},{text:"Au",correct:false},{text:"As",correct:false},{text:"Am",correct:false}]},
  {question:"What is the symbol for Cadmium?",answers:[{text:"Cd",correct:true},{text:"Ca",correct:false},{text:"Cm",correct:false},{text:"Ce",correct:false}]},
  {question:"Indium has which symbol?",answers:[{text:"In",correct:true},{text:"Ir",correct:false},{text:"Io",correct:false},{text:"Is",correct:false}]},
  {question:"Which element has the symbol 'Sn'?",answers:[{text:"Tin",correct:true},{text:"Sb",correct:false},{text:"Si",correct:false},{text:"Sr",correct:false}]}
];

// ================== QUIZ ENGINE ==================
const questionElement = document.getElementById("question");
const answerButtons = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");
const scoreDisplay = document.getElementById("score");

let currentQuestionIndex = 0;
let score = 0;
let questions = [];

function loadSet(set) {
  questions = [...set];
  startQuiz();
}

function startQuiz() {
  currentQuestionIndex = 0;
  score = 0;
  nextButton.innerHTML = "Next";
  scoreDisplay.textContent = "";
  showQuestion();
}

function showQuestion() {
  resetState();
  let currentQuestion = questions[currentQuestionIndex];
  questionElement.innerHTML = currentQuestion.question;

  currentQuestion.answers.forEach(answer => {
    const button = document.createElement("button");
    button.innerHTML = answer.text;
    button.classList.add("btn");
    answerButtons.appendChild(button);
    if (answer.correct) {
      button.dataset.correct = answer.correct;
    }
    button.addEventListener("click", selectAnswer);
  });
}

function resetState() {
  nextButton.style.display = "none";
  while (answerButtons.firstChild) {
    answerButtons.removeChild(answerButtons.firstChild);
  }
}

function selectAnswer(e) {
  const selectedBtn = e.target;
  const isCorrect = selectedBtn.dataset.correct === "true";
  if (isCorrect) {
    selectedBtn.classList.add("correct");
    score++;
  } else {
    selectedBtn.classList.add("wrong");
  }
  Array.from(answerButtons.children).forEach(button => {
    if (button.dataset.correct === "true") {
      button.classList.add("correct");
    }
    button.disabled = true;
  });
  nextButton.style.display = "block";
}

function showScore() {
  resetState();
  questionElement.innerHTML = `You scored ${score} out of ${questions.length}!`;
  scoreDisplay.textContent = "";
  nextButton.innerHTML = "Play Again";
  nextButton.style.display = "block";
}

function handleNextButton() {
  currentQuestionIndex++;
  if (currentQuestionIndex < questions.length) {
    showQuestion();
  } else {
    showScore();
  }
}

nextButton.addEventListener("click", () => {
  if (currentQuestionIndex < questions.length) {
    handleNextButton();
  } else {
    startQuiz();
  }
});
